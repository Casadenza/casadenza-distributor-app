import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionFromRequest } from "@/app/api/_session";

export const runtime = "nodejs";

export async function GET(req: Request) {
  try {
    const session = await getSessionFromRequest(req);

    // Distributor + Admin both allowed
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    if (session.role !== "ADMIN" && session.role !== "DISTRIBUTOR") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const url = new URL(req.url);

    const activeParam = url.searchParams.get("active") || "1";
    const takeRaw = Number(url.searchParams.get("take") || "5000");
    const take = Math.min(Math.max(Number(takeRaw) || 5000, 1), 10000);

    const where: any = {};

    if (activeParam !== "all") {
      const activeBool = activeParam === "1";
      where.isActive = activeBool;
      where.product = { isActive: activeBool };
    }

    const items = await db.productVariant.findMany({
      where,
      include: {
        product: true,
      },
      orderBy: [
        { product: { collection: "asc" } },
        { product: { stoneType: "asc" } },
        { sizeLabel: "asc" },
      ],
      take,
    });

    return NextResponse.json({ items });
  } catch (e: any) {
    return NextResponse.json(
      { error: "Server error", detail: String(e?.message || e) },
      { status: 500 }
    );
  }
}